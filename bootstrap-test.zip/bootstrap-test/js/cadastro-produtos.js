// ===================================
// CADASTRO DE PRODUTOS
// ===================================

document.addEventListener("DOMContentLoaded", () => {
  const productForm = document.getElementById("productForm")
  const btnClear = document.getElementById("btnClear")
  const btnCancel = document.getElementById("btnCancel")
  const successAlert = document.getElementById("successAlert")

  // Validação e submissão do formulário
  productForm.addEventListener("submit", (event) => {
    event.preventDefault()
    event.stopPropagation()

    if (productForm.checkValidity()) {
      // Coletar dados do formulário
      const formData = {
        name: document.getElementById("productName").value,
        sku: document.getElementById("productSKU").value,
        category: document.getElementById("productCategory").value,
        quantity: document.getElementById("productQuantity").value,
        price: document.getElementById("productPrice").value,
        supplier: document.getElementById("productSupplier").value,
        minStock: document.getElementById("productMinStock").value,
        location: document.getElementById("productLocation").value,
        description: document.getElementById("productDescription").value,
        active: document.getElementById("productActive").checked,
      }

      console.log("Produto cadastrado:", formData)

      // Simular salvamento
      setTimeout(() => {
        // Mostrar alerta de sucesso
        successAlert.classList.remove("d-none")
        successAlert.classList.add("show")

        // Limpar formulário
        productForm.reset()
        productForm.classList.remove("was-validated")

        // Scroll para o topo
        window.scrollTo({ top: 0, behavior: "smooth" })

        // Esconder alerta após 5 segundos
        setTimeout(() => {
          successAlert.classList.remove("show")
          setTimeout(() => {
            successAlert.classList.add("d-none")
          }, 150)
        }, 5000)
      }, 500)
    } else {
      productForm.classList.add("was-validated")
    }
  })

  // Botão Limpar
  btnClear.addEventListener("click", () => {
    if (confirm("Deseja realmente limpar todos os campos do formulário?")) {
      productForm.reset()
      productForm.classList.remove("was-validated")
      console.log("Formulário limpo")
    }
  })

  // Botão Cancelar
  btnCancel.addEventListener("click", () => {
    if (confirm("Deseja cancelar o cadastro? Os dados não salvos serão perdidos.")) {
      window.location.href = "dashboard.html"
    }
  })

  // Formatar preço em tempo real
  const priceInput = document.getElementById("productPrice")
  priceInput.addEventListener("blur", function () {
    if (this.value) {
      this.value = Number.parseFloat(this.value).toFixed(2)
    }
  })

  // Auto-gerar SKU (exemplo básico)
  const categorySelect = document.getElementById("productCategory")
  const skuInput = document.getElementById("productSKU")

  categorySelect.addEventListener("change", function () {
    if (!skuInput.value) {
      const prefix = this.value.substring(0, 3).toUpperCase()
      const random = Math.floor(Math.random() * 1000)
        .toString()
        .padStart(3, "0")
      skuInput.value = `${prefix}-${random}`
    }
  })
})
