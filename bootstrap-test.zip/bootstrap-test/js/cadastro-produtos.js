// ===================================
// CADASTRO DE PRODUTOS
// ===================================

document.addEventListener("DOMContentLoaded", () => {
  const productForm = document.getElementById("productForm")
  const btnClear = document.getElementById("btnClear")
  const btnCancel = document.getElementById("btnCancel")
  const successAlert = document.getElementById("successAlert")

  productForm.addEventListener("submit", (event) => {
    event.preventDefault()
    event.stopPropagation()

    if (productForm.checkValidity()) {
      const formData = {
        name: document.getElementById("productName").value,
        sku: document.getElementById("productSKU").value,
        category: document.getElementById("productCategory").value,
        quantity: document.getElementById("productQuantity").value,
        price: document.getElementById("productPrice").value,
        supplier: document.getElementById("productSupplier").value,
        minStock: document.getElementById("productMinStock").value,
        location: document.getElementById("productLocation").value,
        description: document.getElementById("productDescription").value,
        active: document.getElementById("productActive").checked,
      }

      setTimeout(() => {
        successAlert.classList.remove("d-none")
        successAlert.classList.add("show")

        productForm.reset()
        productForm.classList.remove("was-validated")

        window.scrollTo({ top: 0, behavior: "smooth" })

        setTimeout(() => {
          successAlert.classList.remove("show")
          setTimeout(() => {
            successAlert.classList.add("d-none")
          }, 150)
        }, 5000)
      }, 500)
    } else {
      productForm.classList.add("was-validated")
    }
  })

  btnClear.addEventListener("click", () => {
    if (confirm("Deseja realmente limpar todos os campos do formulário?")) {
      productForm.reset()
      productForm.classList.remove("was-validated")
    }
  })

  btnCancel.addEventListener("click", () => {
    if (confirm("Deseja cancelar o cadastro? Os dados não salvos serão perdidos.")) {
      window.location.href = "dashboard.html"
    }
  })

  const priceInput = document.getElementById("productPrice")
  priceInput.addEventListener("blur", function () {
    if (this.value) {
      this.value = Number.parseFloat(this.value).toFixed(2)
    }
  })

  const categorySelect = document.getElementById("productCategory")
  const skuInput = document.getElementById("productSKU")

  categorySelect.addEventListener("change", function () {
    if (!skuInput.value) {
      const prefix = this.value.substring(0, 3).toUpperCase()
      const random = Math.floor(Math.random() * 1000)
        .toString()
        .padStart(3, "0")
      skuInput.value = `${prefix}-${random}`
    }
  })
})
