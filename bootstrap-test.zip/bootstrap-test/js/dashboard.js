// ===================================
// FUNCIONALIDADES DO DASHBOARD
// ===================================

document.addEventListener("DOMContentLoaded", () => {
  animateCards()
  updateDashboardData()
})

function animateCards() {
  const cards = document.querySelectorAll(".card")
  cards.forEach((card, index) => {
    card.style.opacity = "0"
    card.style.transform = "translateY(20px)"

    setTimeout(() => {
      card.style.transition = "all 0.5s ease"
      card.style.opacity = "1"
      card.style.transform = "translateY(0)"
    }, index * 100)
  })
}

function updateDashboardData() {}

function formatNumber(num) {
  return new Intl.NumberFormat("pt-BR").format(num)
}

function formatCurrency(value) {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value)
}

setInterval(() => {}, 30000)
