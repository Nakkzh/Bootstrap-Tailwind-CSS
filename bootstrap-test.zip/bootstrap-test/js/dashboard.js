// ===================================
// FUNCIONALIDADES DO DASHBOARD
// ===================================

document.addEventListener("DOMContentLoaded", () => {
  console.log("Dashboard carregado com sucesso!")

  // Animar os cards ao carregar
  animateCards()

  // Atualizar dados dinamicamente (simulação)
  updateDashboardData()
})

// Animar cards ao carregar
function animateCards() {
  const cards = document.querySelectorAll(".card")
  cards.forEach((card, index) => {
    card.style.opacity = "0"
    card.style.transform = "translateY(20px)"

    setTimeout(() => {
      card.style.transition = "all 0.5s ease"
      card.style.opacity = "1"
      card.style.transform = "translateY(0)"
    }, index * 100)
  })
}

// Simular atualização de dados em tempo real
function updateDashboardData() {
  // Esta função poderia fazer chamadas AJAX para atualizar os dados
  console.log("Dados do dashboard atualizados")
}

// Função para formatar números
function formatNumber(num) {
  return new Intl.NumberFormat("pt-BR").format(num)
}

// Função para formatar moeda
function formatCurrency(value) {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value)
}

// Auto-refresh dos alertas (exemplo)
setInterval(() => {
  console.log("Verificando novos alertas...")
  // Aqui poderia fazer uma chamada para verificar novos alertas
}, 30000) // A cada 30 segundos
