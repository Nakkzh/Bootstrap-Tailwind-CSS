// ===================================
// GERENCIAMENTO DE ESTOQUE
// ===================================

document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.getElementById("searchInput")
  const filterCategory = document.getElementById("filterCategory")
  const filterStatus = document.getElementById("filterStatus")
  const btnClearFilters = document.getElementById("btnClearFilters")
  const btnConfirmAdjust = document.getElementById("btnConfirmAdjust")
  const adjustStockForm = document.getElementById("adjustStockForm")
  const bootstrap = window.bootstrap

  searchInput.addEventListener("input", function () {
    const searchTerm = this.value.toLowerCase()
    filterTable(searchTerm)
  })

  filterCategory.addEventListener("change", () => {
    applyFilters()
  })

  filterStatus.addEventListener("change", () => {
    applyFilters()
  })

  btnClearFilters.addEventListener("click", () => {
    searchInput.value = ""
    filterCategory.value = ""
    filterStatus.value = ""
    showAllRows()
  })

  btnConfirmAdjust.addEventListener("click", () => {
    if (adjustStockForm.checkValidity()) {
      const adjustmentType = document.getElementById("adjustmentType").value
      const adjustmentQuantity = document.getElementById("adjustmentQuantity").value
      const adjustmentReason = document.getElementById("adjustmentReason").value

      const modal = bootstrap.Modal.getInstance(document.getElementById("adjustStockModal"))
      modal.hide()

      setTimeout(() => {
        alert("Estoque ajustado com sucesso!")
        adjustStockForm.reset()
        adjustStockForm.classList.remove("was-validated")
      }, 300)
    } else {
      adjustStockForm.classList.add("was-validated")
    }
  })

  function filterTable(searchTerm) {
    const tableRows = document.querySelectorAll("tbody tr")

    tableRows.forEach((row) => {
      const text = row.textContent.toLowerCase()
      if (text.includes(searchTerm)) {
        row.style.display = ""
      } else {
        row.style.display = "none"
      }
    })

    updateResultCount()
  }

  function applyFilters() {
    const searchTerm = searchInput.value.toLowerCase()
    const categoryFilter = filterCategory.value
    const statusFilter = filterStatus.value
    const tableRows = document.querySelectorAll("tbody tr")

    tableRows.forEach((row) => {
      let showRow = true

      if (searchTerm && !row.textContent.toLowerCase().includes(searchTerm)) {
        showRow = false
      }

      if (categoryFilter) {
        const categoryBadge = row.querySelector(".badge")
        if (!categoryBadge || !categoryBadge.textContent.toLowerCase().includes(categoryFilter)) {
          showRow = false
        }
      }

      if (statusFilter) {
        const statusBadge = row.querySelectorAll(".badge")[1]
        if (statusFilter === "ok" && !statusBadge.classList.contains("bg-success")) {
          showRow = false
        } else if (statusFilter === "baixo" && !statusBadge.classList.contains("bg-warning")) {
          showRow = false
        } else if (statusFilter === "zerado" && !statusBadge.classList.contains("bg-danger")) {
          showRow = false
        }
      }

      row.style.display = showRow ? "" : "none"
    })

    updateResultCount()
  }

  function showAllRows() {
    const tableRows = document.querySelectorAll("tbody tr")
    tableRows.forEach((row) => {
      row.style.display = ""
    })
    updateResultCount()
  }

  function updateResultCount() {
    const visibleRows = document.querySelectorAll('tbody tr[style=""]').length
    const resultBadge = document.querySelector(".badge.bg-primary")
    if (resultBadge) {
      resultBadge.textContent = `${visibleRows} produtos encontrados`
    }
  }

  document.querySelectorAll(".btn-outline-danger").forEach((btn) => {
    btn.addEventListener("click", function () {
      if (confirm("Tem certeza que deseja excluir este produto? Esta ação não pode ser desfeita.")) {
        const row = this.closest("tr")
        row.style.transition = "opacity 0.3s"
        row.style.opacity = "0"
        setTimeout(() => {
          row.remove()
          updateResultCount()
          alert("Produto excluído com sucesso!")
        }, 300)
      }
    })
  })
})
