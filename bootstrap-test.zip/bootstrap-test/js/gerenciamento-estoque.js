// ===================================
// GERENCIAMENTO DE ESTOQUE
// ===================================

document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.getElementById("searchInput")
  const filterCategory = document.getElementById("filterCategory")
  const filterStatus = document.getElementById("filterStatus")
  const btnClearFilters = document.getElementById("btnClearFilters")
  const btnConfirmAdjust = document.getElementById("btnConfirmAdjust")
  const adjustStockForm = document.getElementById("adjustStockForm")
  const bootstrap = window.bootstrap // Declare the bootstrap variable

  // Busca em tempo real
  searchInput.addEventListener("input", function () {
    const searchTerm = this.value.toLowerCase()
    filterTable(searchTerm)
  })

  // Filtro por categoria
  filterCategory.addEventListener("change", () => {
    applyFilters()
  })

  // Filtro por status
  filterStatus.addEventListener("change", () => {
    applyFilters()
  })

  // Limpar filtros
  btnClearFilters.addEventListener("click", () => {
    searchInput.value = ""
    filterCategory.value = ""
    filterStatus.value = ""
    showAllRows()
    console.log("Filtros limpos")
  })

  // Confirmar ajuste de estoque
  btnConfirmAdjust.addEventListener("click", () => {
    if (adjustStockForm.checkValidity()) {
      const adjustmentType = document.getElementById("adjustmentType").value
      const adjustmentQuantity = document.getElementById("adjustmentQuantity").value
      const adjustmentReason = document.getElementById("adjustmentReason").value

      console.log("Ajuste de estoque:", {
        type: adjustmentType,
        quantity: adjustmentQuantity,
        reason: adjustmentReason,
      })

      // Fechar modal
      const modal = bootstrap.Modal.getInstance(document.getElementById("adjustStockModal"))
      modal.hide()

      // Mostrar mensagem de sucesso
      setTimeout(() => {
        alert("Estoque ajustado com sucesso!")
        adjustStockForm.reset()
        adjustStockForm.classList.remove("was-validated")
      }, 300)
    } else {
      adjustStockForm.classList.add("was-validated")
    }
  })

  // Função para filtrar tabela por busca
  function filterTable(searchTerm) {
    const tableRows = document.querySelectorAll("tbody tr")

    tableRows.forEach((row) => {
      const text = row.textContent.toLowerCase()
      if (text.includes(searchTerm)) {
        row.style.display = ""
      } else {
        row.style.display = "none"
      }
    })

    updateResultCount()
  }

  // Aplicar múltiplos filtros
  function applyFilters() {
    const searchTerm = searchInput.value.toLowerCase()
    const categoryFilter = filterCategory.value
    const statusFilter = filterStatus.value
    const tableRows = document.querySelectorAll("tbody tr")

    tableRows.forEach((row) => {
      let showRow = true

      // Filtro de busca
      if (searchTerm && !row.textContent.toLowerCase().includes(searchTerm)) {
        showRow = false
      }

      // Filtro de categoria
      if (categoryFilter) {
        const categoryBadge = row.querySelector(".badge")
        if (!categoryBadge || !categoryBadge.textContent.toLowerCase().includes(categoryFilter)) {
          showRow = false
        }
      }

      // Filtro de status
      if (statusFilter) {
        const statusBadge = row.querySelectorAll(".badge")[1]
        if (statusFilter === "ok" && !statusBadge.classList.contains("bg-success")) {
          showRow = false
        } else if (statusFilter === "baixo" && !statusBadge.classList.contains("bg-warning")) {
          showRow = false
        } else if (statusFilter === "zerado" && !statusBadge.classList.contains("bg-danger")) {
          showRow = false
        }
      }

      row.style.display = showRow ? "" : "none"
    })

    updateResultCount()
  }

  // Mostrar todas as linhas
  function showAllRows() {
    const tableRows = document.querySelectorAll("tbody tr")
    tableRows.forEach((row) => {
      row.style.display = ""
    })
    updateResultCount()
  }

  // Atualizar contador de resultados
  function updateResultCount() {
    const visibleRows = document.querySelectorAll('tbody tr[style=""]').length
    const resultBadge = document.querySelector(".badge.bg-primary")
    if (resultBadge) {
      resultBadge.textContent = `${visibleRows} produtos encontrados`
    }
  }

  // Confirmação de exclusão
  document.querySelectorAll(".btn-outline-danger").forEach((btn) => {
    btn.addEventListener("click", function () {
      if (confirm("Tem certeza que deseja excluir este produto? Esta ação não pode ser desfeita.")) {
        const row = this.closest("tr")
        row.style.transition = "opacity 0.3s"
        row.style.opacity = "0"
        setTimeout(() => {
          row.remove()
          updateResultCount()
          alert("Produto excluído com sucesso!")
        }, 300)
      }
    })
  })
})
