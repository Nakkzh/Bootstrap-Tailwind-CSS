// ===================================
// FORMULÁRIO DE LOGIN
// ===================================

document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("loginForm")
  const togglePassword = document.getElementById("togglePassword")
  const passwordInput = document.getElementById("password")
  const eyeIcon = document.getElementById("eyeIcon")
  const forgotPasswordForm = document.getElementById("forgotPasswordForm")

  const bootstrap = window.bootstrap

  loginForm.addEventListener("submit", (event) => {
    event.preventDefault()
    event.stopPropagation()

    if (loginForm.checkValidity()) {
      const email = document.getElementById("email").value
      const password = document.getElementById("password").value

      loginForm.classList.add("was-validated")

      setTimeout(() => {
        alert("Login realizado com sucesso!")
        window.location.href = "dashboard.html"
      }, 500)
    } else {
      loginForm.classList.add("was-validated")
    }
  })

  if (togglePassword) {
    togglePassword.addEventListener("click", () => {
      const type = passwordInput.getAttribute("type") === "password" ? "text" : "password"
      passwordInput.setAttribute("type", type)

      if (type === "password") {
        eyeIcon.classList.remove("bi-eye-slash")
        eyeIcon.classList.add("bi-eye")
      } else {
        eyeIcon.classList.remove("bi-eye")
        eyeIcon.classList.add("bi-eye-slash")
      }
    })
  }

  if (forgotPasswordForm) {
    forgotPasswordForm.addEventListener("submit", (event) => {
      event.preventDefault()
      event.stopPropagation()

      if (forgotPasswordForm.checkValidity()) {
        const email = document.getElementById("recoveryEmail").value

        const modal = bootstrap.Modal.getInstance(document.getElementById("forgotPasswordModal"))
        modal.hide()

        setTimeout(() => {
          alert("Instruções de recuperação enviadas para: " + email)
          forgotPasswordForm.reset()
        }, 300)
      } else {
        forgotPasswordForm.classList.add("was-validated")
      }
    })
  }

  const loginCard = document.querySelector(".card")
  if (loginCard) {
    loginCard.style.opacity = "0"
    loginCard.style.transform = "translateY(20px)"

    setTimeout(() => {
      loginCard.style.transition = "all 0.6s ease"
      loginCard.style.opacity = "1"
      loginCard.style.transform = "translateY(0)"
    }, 100)
  }
})
