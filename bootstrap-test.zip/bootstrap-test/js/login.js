// ===================================
// VALIDAÇÃO DO FORMULÁRIO DE LOGIN
// ===================================

document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("loginForm")
  const togglePassword = document.getElementById("togglePassword")
  const passwordInput = document.getElementById("password")
  const eyeIcon = document.getElementById("eyeIcon")
  const forgotPasswordForm = document.getElementById("forgotPasswordForm")

  // Import Bootstrap Modal
  const bootstrap = window.bootstrap

  // Validação do formulário de login
  loginForm.addEventListener("submit", (event) => {
    event.preventDefault()
    event.stopPropagation()

    if (loginForm.checkValidity()) {
      // Simular login bem-sucedido
      const email = document.getElementById("email").value
      const password = document.getElementById("password").value

      console.log("Tentativa de login:", { email, password })

      // Adicionar classe de validação
      loginForm.classList.add("was-validated")

      // Simular redirecionamento após login
      setTimeout(() => {
        alert("Login realizado com sucesso!")
        window.location.href = "dashboard.html"
      }, 500)
    } else {
      loginForm.classList.add("was-validated")
    }
  })

  // Toggle mostrar/ocultar senha
  if (togglePassword) {
    togglePassword.addEventListener("click", () => {
      const type = passwordInput.getAttribute("type") === "password" ? "text" : "password"
      passwordInput.setAttribute("type", type)

      // Trocar o ícone
      if (type === "password") {
        eyeIcon.classList.remove("bi-eye-slash")
        eyeIcon.classList.add("bi-eye")
      } else {
        eyeIcon.classList.remove("bi-eye")
        eyeIcon.classList.add("bi-eye-slash")
      }
    })
  }

  // Formulário de recuperação de senha
  if (forgotPasswordForm) {
    forgotPasswordForm.addEventListener("submit", (event) => {
      event.preventDefault()
      event.stopPropagation()

      if (forgotPasswordForm.checkValidity()) {
        const email = document.getElementById("recoveryEmail").value
        console.log("Recuperação de senha solicitada para:", email)

        // Fechar modal e mostrar mensagem de sucesso
        const modal = bootstrap.Modal.getInstance(document.getElementById("forgotPasswordModal"))
        modal.hide()

        setTimeout(() => {
          alert("Instruções de recuperação enviadas para: " + email)
          forgotPasswordForm.reset()
        }, 300)
      } else {
        forgotPasswordForm.classList.add("was-validated")
      }
    })
  }

  // Adicionar animação ao carregar a página
  const loginCard = document.querySelector(".card")
  if (loginCard) {
    loginCard.style.opacity = "0"
    loginCard.style.transform = "translateY(20px)"

    setTimeout(() => {
      loginCard.style.transition = "all 0.6s ease"
      loginCard.style.opacity = "1"
      loginCard.style.transform = "translateY(0)"
    }, 100)
  }
})
